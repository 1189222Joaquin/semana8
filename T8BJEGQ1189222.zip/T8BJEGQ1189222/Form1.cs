namespace T8BJEGQ1189222
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(textBox1.Text);
            double r = 0;
            string resultado = "";
            do
            {
                r = ((double)(x)) / 16;
                x = x / 16;
                r = (r - x) * 16;

                if (r == 10)
                    resultado = "A" + resultado;
                else if (r == 11)
                    resultado = "B" + resultado;
                else if (r == 12)
                    resultado = "C" + resultado;
                else if (r == 13)
                    resultado = "D" + resultado;
                else if (r == 14)
                    resultado = "E" + resultado;
                else if (r == 15)
                    resultado = "F" + resultado;
                else
                    resultado = r + resultado; 
            } while (x != 0);
            label2.Text = "El numero hexadecimal es: " + resultado;
        }
    }
}