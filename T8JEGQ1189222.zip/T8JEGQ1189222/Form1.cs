namespace T8JEGQ1189222
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(textBox1.Text);
            string y = ""; 
            while (x > 0)
            {
                y = x % 2 + y;
                x = x / 2;
            }
            label2.Text = "El numero binario es: " + y;
        }
    }
}