namespace T7_JEGQ_1189222
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double n = double.Parse(textBox1.Text);
            double s = 0;
            double x = 1;

            do
            {
                s = s + 1 / x;
                x++;
            }
            while (x <= n); 
            label2.Text = "Sumatoria es: " + s;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox2.Text);
            double y = 0;
            double z = 1;

            do
            {
                y = y + 1 / Math.Pow (2,x);
                z++;
            }
            while (z <= x);
            label4.Text = "Sumatoria en n es: " + y;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox1.Text);
            double n = double.Parse(textBox2.Text);
            double a = double.Parse(textBox3.Text);
            double suma = 0;

            do
            {
                suma = suma + x * Math.Pow(a, n);
                n++;
            }
            while (a <= n);
            label6.Text = "Sumatoria de los 3 es : " + suma;
        }
    }
}